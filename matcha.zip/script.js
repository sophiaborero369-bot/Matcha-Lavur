/* ===== MATCHA LAVUR - script.js ===== */
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const peso = n => '₱' + Number(n).toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2});
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } };
const store = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };

/* ---------- DATA (edit names, prices, images here) ---------- */
const PRODUCTS = [
  {id:1,name:'Blueberry Matcha Spring Latte',cat:'Drinks',price:180,rate:4.9,img:'Blueberry_Matcha Spring Latte.jfif',desc:'Fresh blueberries blended with creamy milk and layered with iced ceremonial matcha.'},
  {id:2,name:'Dirty Matcha Latte',cat:'Drinks',price:175,rate:4.7,img:'dirty matcha latte.jpg',desc:'Rich espresso layered with fresh milk and ceremonial matcha over ice.'},
  {id:3,name:'Strawberry Matcha',cat:'Drinks',price:215,rate:4.9,img:'StrawberryMatchaLatte-1.jpg',desc:'Ceremonial matcha with fresh milk, sweet strawberry cream, and ice.'},
  {id:4,name:'Honey Cinnamon Matcha',cat:'Drinks',price:205,rate:4.8,img:'honey cinnamon matcha latte.jfif',desc:'Ceremonial matcha with fresh milk, natural honey, and a hint of cinnamon over ice.'},
  {id:5,name:'Iced Matcha Latte',cat:'Drinks',price:175,rate:4.7,img:'Iced Matcha Latte.jpg',desc:'Ceremonial matcha blended with fresh milk over ice, topped with creamy milk foam and matcha powder.'},
  {id:6,name:'Iced Pistachio Matcha Mint Shake',cat:'Drinks',price:225,rate:5,img:'Iced-Pistachio-Matcha-Mint-Shake-.jpg',desc:'Creamy ceremonial matcha blended with pistachio, fresh mint, and milk, topped with whipped cream and crushed pistachios.'},
  {id:7,name:'Mango Sticky Rice Matcha',cat:'Drinks',price:195,rate:4.8,img:'mango-sticky-rice-matcha-latte.jpg',desc:'Ceremonial matcha with fresh milk, sweet mango puree, and creamy coconut sticky rice over ice.'},
  {id:8,name:'Matcha Bubble Milk Tea',cat:'Drinks',price:165,rate:4.7,img:'matcha bubble milk tea.jpg',desc:'Ceremonial matcha with fresh milk, chewy tapioca pearls, and ice.'},
  {id:9,name:'Matcha Ice Cream Latte',cat:'Drinks',price:190,rate:4.9,img:'Matcha Ice Cream Latte with crunchy cookies.jfif',desc:'Creamy ceremonial matcha blended with fresh milk and ice, topped with vanilla ice cream, whipped cream, and crunchy chocolate cookies.'},
  {id:10,name:'Matcha Lemonade',cat:'Drinks',price:155,rate:4.8,img:'Matcha-Lemonade.jpg',desc:'Ceremonial matcha blended with fresh lemonade and ice, topped with a refreshing citrus twist.'},
  {id:11,name:'Matcha Suman',cat:'Drinks',price:190,rate:5,img:'suman.png',desc:'Creamy iced matcha layered with fresh milk, rich latik syrup, topped with whipped cream, toasted coconut flakes, and a piece of sweet suman.'},
  {id:12,name:'Ube Matcha',cat:'Drinks',price:195,rate:4.9,img:'ube.jfif',desc:'Ceremonial matcha blended with sweet ube and fresh milk, served ice-cold and garnished with a slice of real purple yam.'},
  {id:13,name:'Turkish Delight Matcha',cat:'Drinks',price:220,rate:4.7,img:'turkish delight matcha.jpg',desc:'Ceremonial matcha infused with delicate rosewater and pistachio essence, steamed with fresh milk and finished with velvety milk foam.'},
  {id:14,name:'Matcha Gateau au Chocolat Cake',cat:'Sweets',price:2200,rate:4.9,img:'matcha gateau au chocolat.jfif',desc:'Rich ceremonial matcha baked with white chocolate, topped with fresh whipped cream and a fine dusting of green tea powder.'},
  {id:15,name:'Matcha Basque Cheesecake',cat:'Sweets',price:1950,rate:4.8,img:'matcha-basque-cheesecake.jpg',desc:'Creamy ceremonial matcha cheesecake baked with a caramelized top, finished with whipped cream and fresh thyme.'},
  {id:16,name:'Matcha Crepe Cake',cat:'Sweets',price:2500,rate:5,img:'matcha-crepe-cake.jpg',desc:'Delicate layers of paper-thin matcha crepes infused with light green tea cream, dusted with matcha powder and dollops of whipped cream.'},
  {id:17,name:'Matcha Mousse Cake',cat:'Sweets',price:1750,rate:4.8,img:'Matcha-Mousse-Cake-01.jpg',desc:'Silky double-layer mousse with ceremonial matcha and sweet white chocolate over a soft matcha sponge base, dusted with green tea powder.'},
  {id:18,name:'Matcha Strawberry Cake',cat:'Sweets',price:2150,rate:4.9,img:'Matcha-Strawberry cake.jpg',desc:'Light matcha sponge frosted with ceremonial green tea cream, topped with fresh strawberries and edible flowers.'},
  {id:19,name:'Triple Matcha Mousse Cake',cat:'Sweets',price:240,rate:4.9,img:'triple matcha mousse cake.jpg',desc:'Layers of light matcha sponge, silky green tea mousse, and pipe cream topped with fresh raspberries and matcha chocolate bar garnish.'},
  {id:20,name:'Matcha Cupcakes with Cinnamon Buttercream (Box of 12)',cat:'Sweets',price:1250,rate:4.8,img:'Matcha-cupcakes-with cinnamon buttercream.jpg',desc:'Moist ceremonial matcha sponge topped with swirl of spiced cinnamon buttercream and a fine dusting of green tea powder.'},
  {id:21,name:'Matcha Tiramisu',cat:'Sweets',price:220,rate:4.8,img:'Matcha-Tiramisu-.jpg',desc:'Matcha-soaked ladyfingers layered with rich mascarpone cream, finished with a generous dusting of green tea powder.'},
  {id:22,name:'Vegan Matcha Mochi (Box of 6)',cat:'Sweets',price:500,rate:4.9,img:'vegan matcha motchi.jpg',desc:'Chewy rice dough filled with smooth, plant-based ceremonial matcha ice cream.'},
  {id:23,name:'Matcha Cookies (Box of 12)',cat:'Sweets',price:720,rate:4.7,img:'matcha-cookies.jpg',desc:'Soft-baked ceremonial matcha cookies half-dipped in sweet white chocolate and sprinkled with toasted black sesame seeds.'},
  {id:24,name:'Matcha Powder Ceremonial Grade (100g)',cat:'Powder',price:2500,rate:4.9,img:'Matcha powder ceremonial grade 100g asayu japan.jpg',desc:'First-harvest Japanese green tea leaves stone-ground into a fine ceremonial powder, offering a vibrant emerald color with a smooth umami finish.'},
  {id:25,name:'Matcha Green Powder (Chocolate Flavor 30g)',cat:'Powder',price:1250,rate:4.9,img:'matcha green powder chocolate flavor.jfif',desc:'Authentic Kyoto Uji green tea powder subtly infused with a sweet chocolate aroma, offering a smooth finish without added sugar or harsh bitterness.'},
  {id:26,name:'Original Matcha Latte Powder',cat:'Powder',price:2350,rate:4.9,img:'original matcha latte ppowder.jpg',desc:'Ceremonial-grade Japanese Uji matcha lightly sweetened with organic cane sugar, crafted for a smooth, calm energy boost.'},
  {id:27,name:'Matcha Culinary Powder',cat:'Powder',price:1500,rate:4.8,img:'matcha culinary powder.jpg',desc:'100% Japanese green tea leaves from Kagoshima stone-ground into a robust, vibrant powder, perfect for baking, lattes, and culinary creations.'},
  {id:28,name:'Fukujuen Ceremonial Matcha (Pack of 10 sticks)',cat:'Powder',price:2050,rate:4.9,img:'4902405138202_02.jpg',desc:'Double-walled stainless steel tumbler with a ceramic interior, keeping your matcha drinks hot or cold for hours.'},
  {id:29,name:'AquaFlask AquaSip (32oz)',cat:'Merchandise',price:1390,rate:4.8,img:'aquaflask-7388-3478044-1.webp',desc:'32oz double-wall vacuum-insulated stainless steel water bottle in monochromatic Matcha green, keeping drinks cold for up to 24 hours or hot for up to 12 hours.'},
  {id:30,name:'7-Piece Ceramic Matcha Tea Ceremony Gift Set',cat:'Merchandise',price:1800,rate:4.8,img:'matcha tea set.webp',desc:'Authentic Japanese tea ceremony kit featuring a hand-glazed ceramic bowl, bamboo whisk and scoop, sifter, and tea towel.'},
  {id:31,name:'2 Ceramic Matcha Mug',cat:'Merchandise',price:1200,rate:4.8,img:'mug.webp',desc:'A beautiful ceramic mug perfect for enjoying your favorite matcha preparation.'},
  {id:32,name:'Matcha Roll Cow Plush (Sheepydust)',cat:'Merchandise',price:2600,rate:4.9,img:'toy.webp',desc:'Fluffy pastel-green Highland cow plush wearing a leafy headband topped with a mini matcha roll cake slice, complete with an embroidered pink butterfly and a green ribbon tied with a brass bell.'},
  {id:33,name:'Monchhichi Keychain',cat:'Merchandise',price:850,rate:5.0,img:'monchhichi keychain matcha.webp',desc:'Vibrant matcha green Monchhichi plush keychain featuring tea-leaf hair details, twin tails, soft green fur, and a classic bib with a tea cup illustration.'},
  {id:34,name:'Matcha Green Ring-Handle Folding Umbrella with Retractable Drip Sleeve',cat:'Merchandise',price:680,rate:4.9,img:'umbrella.webp',desc:'3-fold compact umbrella featuring a textured floral-embossed matcha green canopy, an ergonomic carabiner ring handle, and a built-in telescopic drip cover that slides over the folded umbrella to keep your bag and car dry.'},
  {id:35,name:'"But First, Matcha" Canvas Tote Bag',cat:'Merchandise',price:480,rate:4.7,img:'tote bag.jpeg',desc:'Eco-friendly off-white cotton canvas tote bag featuring an adorable smiling matcha cup graphic and bold "BUT FIRST Matcha" typography.'}



];
const VOUCHERS = [
  {code:'LAVUR50', label:'P50 off', type:'amt', val:50, min:300},
  {code:'WELCOME100', label:'P100 off', type:'amt', val:100, min:500},
  {code:'FREESHIP', label:'Free shipping', type:'ship', val:0, min:200}
];
const DISCOUNTS = [
  {code:'NEWOPEN10', label:'10% off (New Opening)', type:'pct', val:10, min:0},
  {code:'GRANDOPEN15', label:'15% off', type:'pct', val:15, min:600},
  {code:'MATCHA20', label:'20% off', type:'pct', val:20, min:1000}
];
const SHIP = {std: 49, exp: 99}, SHIP_NAME = {std: 'Standard', exp: 'Express'};
const FAQ = [
  ['How do I place an order?', 'Add items to your cart, open Purchase, fill in your details, choose a payment method and press Place Order.'],
  ['What payment methods are accepted?', 'Cash on Delivery, e-wallets (GCash, Maya and PayPal) and online banking (UnionBank, BDO, BPI and more).'],
  ['How do vouchers and discounts work?', 'On the Purchase page choose either a voucher or a discount. Only one can be used per order and each has a minimum spend.'],
  ['Can I cancel my order?', 'Yes, while it is in To Pay or To Ship. Go to My Purchase and press Cancel Order.'],
  ['How do I return or refund an item?', 'After an order is Completed, open My Purchase > Completed and press Request Return/Refund.'],
  ['How long does delivery take?', 'Standard delivery takes 1 to 3 days within the city. Express is same day. Matcha drinks are prepared fresh and shipped chilled.']
];
const SEED_REVIEWS = [
  {id:'s1', name:'Angela R.', pid:3, stars:5, text:'The strawberry matcha is perfect. Not too sweet and the matcha is rich!', img:'images/review1.jpg', date:'Nov 2, 2026', help:12},
  {id:'s2', name:'Marco D.', pid:12, stars:5, text:'Best matcha basque cheesecake I have tried. Arrived cold and intact.', img:'images/review2.jpg', date:'Nov 1, 2026', help:9},
  {id:'s3', name:'Kyla S.', pid:9, stars:4, text:'Mochi was so soft. Would love more flavors next time.', img:'images/review3.jpg', date:'Oct 30, 2026', help:4},
  {id:'s4', name:'Paolo T.', pid:1, stars:5, text:'My daily iced latte now. Smooth and not bitter at all.', img:'', date:'Oct 28, 2026', help:6},
  {id:'s5', name:'Jen L.', pid:6, stars:3, text:'Tasty frappe but it melted a bit on the way. Still good.', img:'', date:'Oct 27, 2026', help:2}
];
const P = id => PRODUCTS.find(p => p.id === id);
const phImg = (src, label) => `<div class="ph"><img src="${src}" alt=""><span>${label}<br>${src}</span></div>`;
const ICON_BAG = '<div class="empty-ic"><svg viewBox="0 0 24 24"><path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8a3 3 0 016 0"/></svg></div>';

/* ---------- STATE ---------- */
let users = load('ml_users', {}), session = load('ml_session', null), me = null;
let userReviews = load('ml_reviews_user', []), helpful = load('ml_helpful', {});
let cat = 'all', rating = 0, orderTab = 'To Pay', rateOrder = null, rf = 'all', pfPhoto = null, otpOrder = null, typing = false;
const save = () => store('ml_users', users);
let toastT;
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 3000); }
document.addEventListener('error', e => { if (e.target.tagName === 'IMG') e.target.remove(); }, true);
const openModal = id => $('#' + id).hidden = false, closeModal = id => $('#' + id).hidden = true;
document.addEventListener('click', e => { const c = e.target.closest('[data-close]'); if (c) closeModal(c.dataset.close); });
const initial = n => (n || '?').trim()[0].toUpperCase();
function setAv(el, name, photo) { el.style.backgroundImage = photo ? `url(${photo})` : ''; el.textContent = photo ? '' : initial(name); }

/* ---------- AUTH ---------- */
function showAuth(w) {
  $$('[data-auth]').forEach(x => x.classList.toggle('active', x.dataset.auth === w));
  $('#loginForm').hidden = w !== 'login'; $('#signupForm').hidden = w !== 'signup'; $('#resetForm').hidden = w !== 'reset';
  $('.auth-card .tabs').hidden = w === 'reset'; authMsg('');
}
function authMsg(t, ok) { const m = $('#authMsg'); m.textContent = t; m.className = ok ? 'ok' : 'err'; }
$$('[data-auth]').forEach(b => b.onclick = () => showAuth(b.dataset.auth));
$('#forgotLink').onclick = e => { e.preventDefault(); showAuth('reset'); };
$('#backLogin').onclick = e => { e.preventDefault(); showAuth('login'); };
$('#resetForm').onsubmit = e => {
  e.preventDefault(); const em = $('#rsEmail').value.trim().toLowerCase();
  if (!users[em]) return authMsg('No account found with that email.');
  users[em].pass = $('#rsPass').value; save(); showAuth('login'); authMsg('Password updated. You can log in now.', true);
};
const newUser = (name, pass, extra = {}) => ({name, pass, cart: [], orders: [], wish: [], msgs: [], voted: [], profile: {photo: '', phone: '', addr: '', bio: ''}, ...extra});
$('#signupForm').onsubmit = e => {
  e.preventDefault();
  const em = $('#suEmail').value.trim().toLowerCase();
  if ($('#suPass').value !== $('#suPass2').value) return authMsg('Passwords do not match.');
  if (users[em]) return authMsg('Email already registered. Please log in.');
  users[em] = newUser($('#suName').value.trim(), $('#suPass').value); save(); startSession(em);
};
$('#loginForm').onsubmit = e => {
  e.preventDefault();
  const em = $('#liEmail').value.trim().toLowerCase();
  if (!users[em] || users[em].pass !== $('#liPass').value) return authMsg('Wrong email or password.');
  startSession(em);
};
let socName = '';
$('#socBtns').onclick = e => { const b = e.target.closest('[data-soc]'); if (!b) return; socName = b.dataset.soc; $('#socTitle').textContent = 'Continue with ' + socName; $('#socForm').reset(); openModal('socModal'); };
$('#socForm').onsubmit = e => {
  e.preventDefault(); const em = $('#socEmail').value.trim().toLowerCase();
  if (!users[em]) { users[em] = newUser($('#socName').value.trim(), 'social-' + Math.random().toString(36).slice(2), {social: socName}); save(); }
  closeModal('socModal'); startSession(em);
};
function startSession(em) {
  session = em; store('ml_session', em); me = users[em];
  me.profile = me.profile || {photo: '', phone: '', addr: '', bio: ''}; me.voted = me.voted || []; me.msgs = me.msgs || [];
  $('#auth').hidden = true; $('#app').hidden = false;
  $('#coName').value = me.name; $('#coEmail').value = em; $('#coPhone').value = me.profile.phone; $('#coAddr').value = me.profile.addr;
  renderHeader(); go('home'); updateCount(); toast('Welcome to Matcha Lavur!');
}
$('#logout').onclick = () => { session = null; store('ml_session', null); location.reload(); };

/* ---------- PROFILE ---------- */
function renderHeader() { $('#hello').textContent = 'Hi, ' + me.name.split(' ')[0]; setAv($('#avHead'), me.name, me.profile.photo); }
$('#profileBtn').onclick = () => {
  pfPhoto = me.profile.photo; $('#pfName').value = me.name; $('#pfEmail').value = session; $('#pfPhone').value = me.profile.phone;
  $('#pfAddr').value = me.profile.addr; $('#pfBio').value = me.profile.bio; setAv($('#pfAv'), me.name, pfPhoto); openModal('profileModal');
};
$('#pfPhoto').onchange = e => {
  const f = e.target.files[0]; if (!f) return; const fr = new FileReader();
  fr.onload = () => { const im = new Image(); im.onload = () => {
    const c = document.createElement('canvas'), s = 180; c.width = c.height = s; const m = Math.min(im.width, im.height);
    c.getContext('2d').drawImage(im, (im.width - m) / 2, (im.height - m) / 2, m, m, 0, 0, s, s);
    pfPhoto = c.toDataURL('image/jpeg', .85); setAv($('#pfAv'), $('#pfName').value, pfPhoto); }; im.src = fr.result; };
  fr.readAsDataURL(f);
};
$('#pfRemove').onclick = () => { pfPhoto = ''; $('#pfPhoto').value = ''; setAv($('#pfAv'), $('#pfName').value, ''); };
$('#profileForm').onsubmit = e => {
  e.preventDefault(); me.name = $('#pfName').value.trim() || me.name;
  Object.assign(me.profile, {photo: pfPhoto || '', phone: $('#pfPhone').value.trim(), addr: $('#pfAddr').value.trim(), bio: $('#pfBio').value.trim()});
  save(); renderHeader(); closeModal('profileModal'); toast('Profile updated');
};

/* ---------- NAVIGATION ---------- */
function go(page) {
  $$('[data-page]').forEach(s => s.hidden = s.dataset.page !== page);
  $$('#nav button').forEach(b => b.classList.toggle('active', b.dataset.go === page));
  ({products: renderProducts, reviews: renderReviews, checkout: renderCheckout, mypurchase: renderOrders, cart: renderCart, message: renderChat, support: renderFaq})[page]?.();
  window.scrollTo(0, 0);
}
document.addEventListener('click', e => { const t = e.target.closest('[data-go]'); if (t) go(t.dataset.go); });

/* ---------- HOME ---------- */
$('#voucherCards').innerHTML = [...VOUCHERS, ...DISCOUNTS].map(v =>
  `<div class="vcard"><b>${v.label}</b><small>${v.min ? 'Min. spend ' + peso(v.min) : 'No minimum spend'}</small><br>Code: <code>${v.code}</code></div>`).join('');
$$('.flip').forEach(f => f.onclick = () => f.classList.toggle('on'));

/* ---------- PRODUCTS ---------- */
const stars = n => '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n));
function renderProducts() {
  const q = $('#search').value.toLowerCase(), s = $('#sort').value;
  let list = PRODUCTS.filter(p => (cat === 'all' || (cat === 'Wishlist' ? me.wish.includes(p.id) : p.cat === cat)) && (p.name + p.desc).toLowerCase().includes(q));
  if (s === 'asc') list.sort((a, b) => a.price - b.price); if (s === 'desc') list.sort((a, b) => b.price - a.price); if (s === 'rate') list.sort((a, b) => b.rate - a.rate);
  $('#productGrid').innerHTML = list.map(p => `<div class="prod">
    <button class="heart ${me.wish.includes(p.id) ? 'on' : ''}" data-wish="${p.id}" title="Wishlist">♥</button>
    <div class="zoom" data-view="${p.id}">${phImg(p.img, 'PRODUCT PHOTO')}</div>
    <div class="prod-b"><span class="tag">${p.cat}</span><b>${p.name}</b><small class="muted">${p.desc}</small>
    <span class="star">${stars(p.rate)} <small>${p.rate}</small></span><span class="price">${peso(p.price)}</span>
    <button class="btn" data-add="${p.id}">Add to Cart</button></div></div>`).join('') || '<p class="empty">No products found.</p>';
}
$('#search').oninput = $('#sort').onchange = renderProducts;
$('#chips').onclick = e => { const c = e.target.closest('.chip'); if (!c) return; cat = c.dataset.cat; $$('#chips .chip').forEach(x => x.classList.toggle('active', x === c)); renderProducts(); };
document.addEventListener('click', e => {
  const a = e.target.closest('[data-add]'), w = e.target.closest('[data-wish]');
  if (a) {
    const id = +a.dataset.add, it = me.cart.find(i => i.id === id); it ? it.qty++ : me.cart.push({id, qty: 1}); save(); updateCount();
    toast('Added to cart: ' + P(id).name); if (!$('[data-page=cart]').hidden) renderCart();
  }
  if (w) { const id = +w.dataset.wish, i = me.wish.indexOf(id); i < 0 ? me.wish.push(id) : me.wish.splice(i, 1); save(); renderProducts(); }
});

/* ---------- CART ---------- */
function updateCount() { const c = $('#cartCount'); c.textContent = me.cart.reduce((n, i) => n + i.qty, 0); c.classList.remove('bump'); void c.offsetWidth; c.classList.add('bump'); }
const subtotal = () => me.cart.reduce((n, i) => n + P(i.id).price * i.qty, 0);
function renderCart() {
  if (!me.cart.length) return $('#cartBox').innerHTML = `<div class="card empty">${ICON_BAG}<b>Your cart is empty</b><p>Add some matcha to get started.</p><button class="btn" data-go="products">Start Shopping</button></div>`;
  const sub = subtotal(), offers = [...VOUCHERS, ...DISCOUNTS].filter(v => v.min > sub).sort((a, b) => a.min - b.min), nx = offers[0];
  const prog = nx ? `Add <b>${peso(nx.min - sub)}</b> more to unlock <b>${nx.code}</b> (${nx.label}).<i style="--w:${Math.min(100, sub / nx.min * 100)}%"></i>` : `You qualify for every voucher and discount. Choose one at checkout!<i style="--w:100%"></i>`;
  const sugg = PRODUCTS.filter(p => !me.cart.some(i => i.id === p.id)).sort((a, b) => b.rate - a.rate).slice(0, 4);
  $('#cartBox').innerHTML = `<div class="cart-layout"><div>
    <div class="cart-top"><span>${me.cart.reduce((n, i) => n + i.qty, 0)} item(s) in your cart</span><button data-clear>Clear cart</button></div>
    ${me.cart.map(i => { const p = P(i.id); return `<div class="cart-row">${phImg(p.img, 'PHOTO')}
      <div class="cart-info"><span class="tag">${p.cat}</span><b>${p.name}</b><span class="muted">${peso(p.price)} each</span>
      <div class="links"><button data-sv="${i.id}">Save for later</button><button class="rm" data-rm="${i.id}">Remove</button></div></div>
      <div class="cart-end"><div class="qty"><button data-q="${i.id}" data-d="-1">-</button><b>${i.qty}</b><button data-q="${i.id}" data-d="1">+</button></div><b class="price">${peso(p.price * i.qty)}</b></div></div>`; }).join('')}</div>
    <aside class="card cart-sum"><h4>Order Summary</h4><div class="prog">${prog}</div>
      <div class="row"><span>Subtotal</span><span>${peso(sub)}</span></div><div class="row"><span>Shipping</span><span>from ${peso(SHIP.std)}</span></div>
      <div class="row total"><span>Estimated Total</span><span>${peso(sub + SHIP.std)}</span></div>
      <button class="btn big" data-go="checkout">Proceed to Purchase</button></aside></div>
    <h4 class="sec-h">You may also like</h4><div class="mini">${sugg.map(p => `<div><b>${p.name}</b><span class="price">${peso(p.price)}</span><button class="btn small" data-add="${p.id}">Add to Cart</button></div>`).join('')}</div>`;
}
$('#cartBox').onclick = e => {
  const q = e.target.closest('[data-q]'), r = e.target.closest('[data-rm]'), s = e.target.closest('[data-sv]'), c = e.target.closest('[data-clear]');
  if (q) { const it = me.cart.find(i => i.id == q.dataset.q); it.qty += +q.dataset.d; if (it.qty < 1) me.cart = me.cart.filter(i => i !== it); }
  if (r) me.cart = me.cart.filter(i => i.id != r.dataset.rm);
  if (s) { const id = +s.dataset.sv; if (!me.wish.includes(id)) me.wish.push(id); me.cart = me.cart.filter(i => i.id !== id); toast('Saved to your wishlist'); }
  if (c && confirm('Remove all items from your cart?')) me.cart = [];
  if (q || r || s || c) { save(); updateCount(); renderCart(); }
};

/* ---------- CHECKOUT (PURCHASE) ---------- */
const val = n => document.querySelector(`input[name=${n}]:checked`).value;
function calc() {
  const sub = subtotal(); let ship = me.cart.length ? SHIP[val('ship')] : 0, disc = 0, msg = '', code = null;
  const mode = val('promo');
  if (mode !== 'none') {
    const v = (mode === 'voucher' ? VOUCHERS : DISCOUNTS).find(x => x.code === $('#promoSel').value);
    if (v) {
      if (sub < v.min) msg = `Spend at least ${peso(v.min)} to use ${v.code}.`;
      else { code = v.code; if (v.type === 'amt') disc = v.val; if (v.type === 'pct') disc = sub * v.val / 100; if (v.type === 'ship') disc = ship; msg = `${v.code} applied!`; }
    }
  }
  disc = Math.min(disc, sub + ship);
  return {sub, ship, disc, code, msg, total: sub + ship - disc};
}
function syncWallet() {
  const w = val('wallet'), pp = w === 'PayPal';
  $('#walletNo').placeholder = pp ? 'PayPal email address' : w + ' mobile number (09XXXXXXXXX)'; $('#walletNo').type = pp ? 'email' : 'text';
  $('#walletPin').placeholder = pp ? 'PayPal password' : 'MPIN (4 digits)'; $('#walletPin').maxLength = pp ? 40 : 4;
}
function renderCheckout() {
  const empty = !me.cart.length; $('#coEmpty').hidden = !empty; $('#coWrap').hidden = empty; if (empty) return;
  const mode = val('promo'), list = mode === 'voucher' ? VOUCHERS : DISCOUNTS;
  if ($('#promoSel').dataset.mode !== mode) {
    $('#promoSel').dataset.mode = mode; $('#promoSel').hidden = mode === 'none';
    $('#promoSel').innerHTML = mode === 'none' ? '' : list.map(v => `<option value="${v.code}">${v.code} - ${v.label}${v.min ? ' (min ' + peso(v.min) + ')' : ''}</option>`).join('');
  }
  const c = calc();
  $('#coItems').innerHTML = me.cart.map(i => `<div class="item"><span>${i.qty} x ${P(i.id).name}</span><span>${peso(P(i.id).price * i.qty)}</span></div>`).join('');
  $('#sSub').textContent = peso(c.sub); $('#sShip').textContent = peso(c.ship);
  $('#sDisc').textContent = c.disc ? '-' + peso(c.disc) : peso(0); $('#sTotal').textContent = peso(c.total); $('#promoMsg').textContent = c.msg;
  const pay = val('pay'); $('#sub-ewallet').hidden = pay !== 'ewallet'; $('#sub-bank').hidden = pay !== 'bank'; syncWallet(); syncSteps();
}
function syncSteps() {
  const d = $('#coName').value.trim() && $('#coAddr').value.trim() && $('#coEmail').value.trim() && $('#coPhone').value.trim(), pay = val('pay');
  const p = pay === 'cod' || (pay === 'ewallet' && $('#wName').value.trim() && $('#walletNo').value.trim() && $('#walletPin').value) || (pay === 'bank' && $('#bName').value.trim() && $('#bankNo').value && $('#bExp').value && $('#bCvv').value);
  $('#st2').classList.toggle('done', !!d); $('#st3').classList.toggle('done', !!(d && p)); $('#st4').classList.toggle('done', !!(d && p));
}
$('#coForm').addEventListener('change', renderCheckout); $('#coForm').addEventListener('input', syncSteps);
$('#bExp').addEventListener('input', e => { let v = e.target.value.replace(/\D/g, '').slice(0, 4); if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2); e.target.value = v; });
$('#useProfile').onclick = () => {
  $('#coName').value = me.name; $('#coEmail').value = session; $('#coPhone').value = me.profile.phone; $('#coAddr').value = me.profile.addr;
  syncSteps(); toast(me.profile.phone || me.profile.addr ? 'Profile details filled in' : 'Add your phone and address in My Profile first');
};
const last4 = s => '•••• ' + String(s).replace(/\D/g, '').slice(-4);
$('#coForm').onsubmit = e => {
  e.preventDefault(); const err = $('#coErr'); err.textContent = '';
  const phone = $('#coPhone').value.trim(), pay = val('pay'), nm = /^[A-Za-z][A-Za-z .,'-]{1,}$/;
  if (!/^09\d{9}$/.test(phone)) return err.textContent = 'Enter a valid 11-digit contact number starting with 09.';
  let method = 'Cash on Delivery';
  if (pay === 'ewallet') {
    const w = val('wallet'), no = $('#walletNo').value.trim(), pin = $('#walletPin').value;
    if (!nm.test($('#wName').value.trim())) return err.textContent = 'Enter the ' + w + ' account name.';
    if (w === 'PayPal') {
      if (!/^\S+@\S+\.\S+$/.test(no)) return err.textContent = 'Enter a valid PayPal email address.';
      if (pin.length < 6) return err.textContent = 'Enter your PayPal password (at least 6 characters).';
      method = 'PayPal - ' + $('#wName').value.trim() + ' (' + no[0] + '***' + no.slice(no.indexOf('@')) + ')';
    } else {
      if (!/^09\d{9}$/.test(no)) return err.textContent = 'Enter a valid ' + w + ' mobile number (09XXXXXXXXX).';
      if (!/^\d{4}$/.test(pin)) return err.textContent = 'Enter your 4-digit ' + w + ' MPIN.';
      method = w + ' - ' + $('#wName').value.trim() + ' (' + last4(no) + ')';
    }
  }
  if (pay === 'bank') {
    const ex = $('#bExp').value, m = ex.match(/^(0[1-9]|1[0-2])\/(\d{2})$/), now = new Date();
    if (!nm.test($('#bName').value.trim())) return err.textContent = 'Enter the account name.';
    if (!/^\d{10,16}$/.test($('#bankNo').value.trim())) return err.textContent = 'Enter a valid account / card number (10 to 16 digits).';
    if (!m) return err.textContent = 'Enter the expiry date as MM/YY.';
    if (new Date(2000 + +m[2], +m[1], 0, 23, 59) < now) return err.textContent = 'This card or account has expired.';
    if (!/^\d{3,4}$/.test($('#bCvv').value)) return err.textContent = 'Enter the 3 or 4-digit CVV.';
    method = $('#bankName').value + ' Online Banking - ' + $('#bName').value.trim() + ' (' + last4($('#bankNo').value) + ')';
  }
  const c = calc(), o = {id: 'ML' + Date.now().toString().slice(-8), date: new Date().toLocaleString(), items: me.cart.map(i => ({...i})), total: c.total, disc: c.disc, code: c.code,
    method, delivery: SHIP_NAME[val('ship')], note: $('#coNote').value.trim(), status: pay === 'cod' ? 'To Ship' : 'To Pay', rated: false, name: $('#coName').value, addr: $('#coAddr').value, phone};
  me.orders.unshift(o); me.cart = []; save(); updateCount();
  ['wName', 'walletNo', 'walletPin', 'bName', 'bankNo', 'bExp', 'bCvv', 'coNote'].forEach(id => $('#' + id).value = '');
  if (pay === 'cod') { orderTab = 'To Ship'; toast('Order placed!'); go('mypurchase'); } else openOtp(o);
};

/* OTP payment confirmation */
function openOtp(o) { otpOrder = o; $('#otpAmt').textContent = peso(o.total); $('#otpTo').textContent = o.method; $('#otpInput').value = ''; $('#otpErr').textContent = ''; openModal('otpModal'); $('#otpInput').focus(); }
$('#otpForm').onsubmit = e => {
  e.preventDefault(); if ($('#otpInput').value.trim() !== '123456') return $('#otpErr').textContent = 'Incorrect OTP. Please try again.';
  otpOrder.status = 'To Ship'; save(); closeModal('otpModal'); orderTab = 'To Ship'; toast('Payment successful!'); go('mypurchase');
};
$('#otpCancel').onclick = () => { closeModal('otpModal'); orderTab = 'To Pay'; toast('Order saved in To Pay. You can pay anytime.'); go('mypurchase'); };

/* ---------- MY PURCHASE ---------- */
const TABS = ['To Pay', 'To Ship', 'To Receive', 'Completed', 'Return/Refund', 'Cancelled', 'To Rate'], FLOW = ['To Pay', 'To Ship', 'To Receive', 'Completed'];
const ordersOf = t => me.orders.filter(o => t === 'To Rate' ? o.status === 'Completed' && !o.rated : o.status === t);
function renderOrders() {
  const act = me.orders.filter(o => ['To Pay', 'To Ship', 'To Receive'].includes(o.status)).length, spent = me.orders.filter(o => !['Cancelled', 'Return/Refund'].includes(o.status)).reduce((n, o) => n + o.total, 0);
  $('#orderStats').innerHTML = `<div class="stat"><small>Total orders</small><b>${me.orders.length}</b></div><div class="stat"><small>In progress</small><b>${act}</b></div><div class="stat"><small>Total spent</small><b>${peso(spent)}</b></div>`;
  $('#orderTabs').innerHTML = TABS.map(t => { const n = ordersOf(t).length; return `<button class="tab ${t === orderTab ? 'active' : ''}" data-tab="${t}">${t}${n ? ' (' + n + ')' : ''}</button>`; }).join('');
  const q = $('#orderSearch').value.trim().toLowerCase();
  const list = ordersOf(orderTab).filter(o => !q || o.id.toLowerCase().includes(q) || o.items.some(i => P(i.id).name.toLowerCase().includes(q)));
  $('#orderList').innerHTML = list.map(o => `<div class="card order"><div class="order-h"><b>Order #${o.id}</b><span class="muted">${o.date}</span><span class="status st-${o.status.replace(/\W+/g, '')}">${o.status}</span></div>
    ${FLOW.includes(o.status) ? `<div class="track">${FLOW.map((s, i) => `<span class="${i <= FLOW.indexOf(o.status) ? 'on' : ''}">${s}</span>`).join('')}</div>` : ''}
    ${o.items.map(i => `<div class="oi">${phImg(P(i.id).img, 'IMG')}<div><b>${P(i.id).name}</b><br><small>Qty ${i.qty} x ${peso(P(i.id).price)}</small></div><b>${peso(P(i.id).price * i.qty)}</b></div>`).join('')}
    <div class="row"><span>Payment: ${o.method}${o.code ? ' | Promo: ' + o.code : ''}${o.delivery ? ' | ' + o.delivery + ' delivery' : ''}</span><b>Total ${peso(o.total)}</b></div>
    <small class="muted">Ship to: ${o.name}, ${o.addr} | ${o.phone}${o.note ? ' | Note: ' + o.note.replace(/</g, '&lt;') : ''}</small><div class="actions">${actions(o)}</div></div>`).join('')
    || `<div class="card empty">${ICON_BAG}<b>${q ? 'No matching orders' : 'No orders under "' + orderTab + '" yet'}</b><p>${q ? 'Try a different order number or product.' : 'Your orders will show up here.'}</p><button class="btn" data-go="products">Shop Matcha</button></div>`;
}
$('#orderSearch').oninput = renderOrders;
function actions(o) {
  const b = (a, l, c = '') => `<button class="btn small ${c}" data-act="${a}" data-id="${o.id}">${l}</button>`;
  return ({'To Pay': b('pay', 'Pay Now') + b('cancel', 'Cancel Order', 'danger'),
    'To Ship': b('ship', 'Seller Ships Order (demo)', 'ghost') + b('cancel', 'Cancel Order', 'danger'),
    'To Receive': b('receive', 'Order Received'),
    'Completed': (o.rated ? '' : b('rate', 'Rate', 'pink')) + b('again', 'Buy Again', 'ghost') + b('ret', 'Request Return/Refund', 'ghost'),
    'Return/Refund': '<span class="muted">Return requested. Refund is being processed by the seller.</span>',
    'Cancelled': b('again', 'Buy Again', 'ghost')})[o.status] || '';
}
$('#orderTabs').onclick = e => { const t = e.target.closest('[data-tab]'); if (t) { orderTab = t.dataset.tab; renderOrders(); } };
$('#orderList').onclick = e => {
  const b = e.target.closest('[data-act]'); if (!b) return; const o = me.orders.find(x => x.id === b.dataset.id), a = b.dataset.act;
  if (a === 'pay') return openOtp(o);
  if (a === 'cancel') { if (!confirm('Cancel this order?')) return; o.status = 'Cancelled'; orderTab = 'Cancelled'; }
  if (a === 'ship') { o.status = 'To Receive'; orderTab = 'To Receive'; toast('Your order is out for delivery'); }
  if (a === 'receive') { o.status = 'Completed'; orderTab = 'Completed'; toast('Order completed. Please rate your items!'); }
  if (a === 'ret') { const r = prompt('Reason for return/refund?'); if (!r) return; o.status = 'Return/Refund'; orderTab = 'Return/Refund'; }
  if (a === 'again') { o.items.forEach(i => { const c = me.cart.find(x => x.id === i.id); c ? c.qty += i.qty : me.cart.push({...i}); }); updateCount(); save(); return go('cart'); }
  if (a === 'rate') { rateOrder = o; save(); return go('reviews'); }
  save(); renderOrders();
};

/* ---------- REVIEWS ---------- */
const allReviews = () => [...userReviews, ...SEED_REVIEWS];
function renderReviews() {
  const opts = rateOrder ? rateOrder.items.map(i => P(i.id)) : PRODUCTS, all = allReviews();
  $('#rvProduct').innerHTML = opts.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
  $('#rateNote').textContent = rateOrder ? `Rating order #${rateOrder.id}` : 'Choose a product and tell us what you think.';
  $('#stars').innerHTML = [1, 2, 3, 4, 5].map(n => `<button type="button" class="${n <= rating ? 'on' : ''}" data-s="${n}">★</button>`).join('');
  const avg = all.reduce((n, r) => n + r.stars, 0) / all.length;
  $('#rSummary').innerHTML = `<div><span class="big">${avg.toFixed(1)}</span><span class="star">${stars(avg)}</span><small class="muted">${all.length} reviews</small></div>
    <div class="bars">${[5, 4, 3, 2, 1].map(n => { const c = all.filter(r => r.stars === n).length; return `<div><span>${n}★</span><i style="--w:${c / all.length * 100}%"></i><span>${c}</span></div>`; }).join('')}</div>`;
  const list = all.filter(r => rf === 'all' || (rf === 'photo' ? r.img : rf === '3' ? r.stars <= 3 : r.stars === +rf));
  $('#reviewList').innerHTML = list.map(r => { const n = (r.help || 0) + (helpful[r.id] || 0), on = me.voted.includes(r.id), p = P(r.pid);
    return `<div class="card rv"><span class="rv-av">${initial(r.name)}</span><div class="rv-main"><div class="rv-top"><b>${r.name}</b><small>${r.date}</small></div>
    <span class="star">${stars(r.stars)}</span><p><span class="tag">${p ? p.name : 'Product'}</span></p><p>${r.text}</p>
    <button class="helpful ${on ? 'on' : ''}" data-help="${r.id}">Helpful (${n})</button></div>${r.img ? phImg(r.img, 'PHOTO') : ''}</div>`; }).join('') || '<div class="card empty">No reviews match this filter yet.</div>';
}
$('#rFilter').onclick = e => { const c = e.target.closest('[data-rf]'); if (!c) return; rf = c.dataset.rf; $$('#rFilter .chip').forEach(x => x.classList.toggle('active', x === c)); renderReviews(); };
$('#reviewList').onclick = e => {
  const h = e.target.closest('[data-help]'); if (!h) return; const id = h.dataset.help;
  if (me.voted.includes(id)) { me.voted = me.voted.filter(x => x !== id); helpful[id] = (helpful[id] || 1) - 1; } else { me.voted.push(id); helpful[id] = (helpful[id] || 0) + 1; }
  store('ml_helpful', helpful); save(); renderReviews();
};
$('#stars').onclick = e => { const s = e.target.closest('[data-s]'); if (s) { rating = +s.dataset.s; renderReviews(); } };
$('#reviewForm').onsubmit = async e => {
  e.preventDefault(); if (!rating) return toast('Please choose a star rating');
  const f = $('#rvPhoto').files[0];
  const img = f ? await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); }) : '';
  userReviews.unshift({id: 'u' + Date.now(), name: me.name, pid: +$('#rvProduct').value, stars: rating, text: $('#rvText').value.replace(/</g, '&lt;'), img, date: new Date().toLocaleDateString('en-US', {month: 'short', day: 'numeric', year: 'numeric'}), help: 0});
  store('ml_reviews_user', userReviews);
  if (rateOrder) { rateOrder.rated = true; rateOrder = null; save(); }
  rating = 0; e.target.reset(); toast('Thanks for your review!'); renderReviews();
};

/* ---------- MESSAGE ---------- */
const REPLIES = [[/ship|order|track/i, 'You can follow your order under My Purchase. I will update it as soon as it is packed!'], [/bulk|event|party/i, 'Yes, we accept bulk and event orders. Tell me the date and quantity.'], [/voucher|discount|promo/i, 'Check the Home page for our new opening vouchers. You can use one voucher or one discount per order.'], [/price|how much/i, 'Prices are on the Matcha Collection page, drinks from P110 and sweets from P110.']];
const clock = () => new Date().toLocaleTimeString('en-US', {hour: 'numeric', minute: '2-digit'});
function renderChat() {
  if (!me.msgs.length) me.msgs.push({from: 'them', t: 'Hi! Welcome to Matcha Lavur. How can I help you today?', time: clock()});
  const d = new Date(), open = d.getDay() !== 0 && d.getHours() >= 9 && d.getHours() < 18;
  $('#sellerStatus').textContent = open ? 'Online now' : 'Away. Replies when the store opens';
  $('#chatBody').innerHTML = '<span class="dsep">Today</span>' + me.msgs.map(m => `<div class="msg ${m.from}">${m.t}<small>${m.time || ''}</small></div>`).join('') + (typing ? '<div class="msg them typing"><i></i><i></i><i></i></div>' : '');
  $('#chatBody').scrollTop = 1e6;
}
function send(t) {
  if (!t.trim()) return; me.msgs.push({from: 'me', t: t.replace(/</g, '&lt;'), time: clock()}); typing = true; save(); renderChat();
  setTimeout(() => { typing = false; me.msgs.push({from: 'them', t: (REPLIES.find(r => r[0].test(t)) || [0, 'Thanks for your message! The seller will get back to you shortly.'])[1], time: clock()}); save(); renderChat(); }, 1100);
}
$('#chatForm').onsubmit = e => { e.preventDefault(); send($('#chatInput').value); $('#chatInput').value = ''; };
$('#quick').onclick = e => { if (e.target.tagName === 'BUTTON') send(e.target.textContent); };
$('#clearChat').onclick = () => { if (confirm('Clear this conversation?')) { me.msgs = []; save(); renderChat(); } };
$('#shareOrder').onclick = () => { if (!me.orders.length) return toast('You have no orders to share yet'); $('#chatInput').value = 'Hi! I have a question about order #' + me.orders[0].id + '.'; $('#chatInput').focus(); };

/* ---------- SUPPORT ---------- */
function renderFaq() { $('#faq').innerHTML = FAQ.map(f => `<div class="faq-i"><button>${f[0]}</button><p hidden>${f[1]}</p></div>`).join(''); }
$('#faq').onclick = e => { const b = e.target.closest('button'); if (b) b.nextElementSibling.hidden = !b.nextElementSibling.hidden; };
$('#csForm').onsubmit = e => { e.preventDefault(); $('#csDone').textContent = 'Ticket #' + Math.floor(Math.random() * 90000 + 10000) + ' submitted. We will email you soon.'; $('#csMsg').value = ''; };

/* ---------- INIT ---------- */
$$('img').forEach(i => { if (i.complete && !i.naturalWidth) i.remove(); });
if (session && users[session]) startSession(session);
/* ---------- VIEW FULL PRODUCT PICTURE ---------- */
document.addEventListener('click', e => {
  const v = e.target.closest('[data-view]');
  if (v) {
    const p = P(+v.dataset.view);
    $('#imgFull').style.backgroundImage = 'url("' + p.img + '")';
    $('#imgName').textContent = p.name;
    $('#imgDesc').textContent = p.desc + ' | ' + peso(p.price);
    $('#imgAdd').dataset.add = p.id;
    $('#imgAdd').hidden = lock(p);
    openModal('imgModal');
  }
  if (e.target.id === 'imgModal') closeModal('imgModal');
});
$('#imgAdd').addEventListener('click', () => closeModal('imgModal'));
